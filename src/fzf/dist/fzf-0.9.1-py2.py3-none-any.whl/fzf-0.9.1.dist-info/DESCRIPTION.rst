Microsoft Azure CLI 'fzf' Extension
==========================================

This package provides the fzf extension for Azure CLI, which allows use of the fzf interface to select defaults for certain items.

Currently supported:
- Subscription
- Resource group
- Location

.. :changelog:

Release History
===============

0.1.0
++++++
* Initial release.

0.1.1
++++++
* Added better help, fixed dependency info, added better error handling.

0.2.0
++++++
* Implemented fzf functionality internally instead of using a module
* Initial unit testing
* Implemented install functionality

0.9.0
++++++
* Completed unit testing
* Completed pylint

0.9.1
++++++
* Corrected platform call to get architecture properly on Windows.


