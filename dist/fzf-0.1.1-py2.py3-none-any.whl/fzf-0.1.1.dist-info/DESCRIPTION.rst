Microsoft Azure CLI 'fzf' Extension
==========================================

This package provides the fzf extension for Azure CLI, which allows use of the fzf interface to select defaults for certain items.

Currently supported:
- Subscription
- Resource group
- Location

.. :changelog:

Release History
===============

0.1.0
++++++
* Initial release.

0.1.1
++++++
* Added better help, fixed dependency info, added better error handling.

