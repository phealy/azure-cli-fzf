Microsoft Azure CLI 'fzf' Extension
==========================================

This package provides the fzf extension for Azure CLI, which allows use of the fzf interface to select defaults for certain items.

Currently supported:
- Subscription
- Resource group
- Location

.. :changelog:

Release History
===============

0.1.0
++++++
* Initial release.

0.1.1
++++++
* Added better help, fixed dependency info, added better error handling.

0.2.0
++++++
* Implemented fzf functionality internally instead of using a module
* Initial unit testing
* Implemented install functionality

0.9.0
++++++
* Completed unit testing
* Completed pylint

0.9.1
++++++
* Corrected platform call to get architecture properly on Windows.

0.9.2
++++++
* Cleaned up unit tests
* Added --no-default/-d parameter to allow use in scripts for finding a subscription/group/location without changing the default.
* Added more error handling to group/location
* Used a better function to get_resource_groups()
* Moved tabulate call to its own function so that it's not repeated.


